
// ================== Firebase Database ====================










var advice_id_holder = document.getElementById('advice_id');
var advice_holder = document.getElementById('advice');
var dice  = document.getElementById('advice_btn');

dice.addEventListener('click', () => {
    fetch("https://api.adviceslip.com/advice")
    .then(response=>{
        return response.json();
    })
    .then(advicedata =>{
        // console.log(advicedata)
        const xogta = advicedata.slip
        var advice = xogta.advice;
        var advice_id = xogta.id;
        // console.log(advice)
        advice_holder.innerHTML = advice
        advice_id_holder.innerHTML = advice_id
    })
    
})















// let getJoke = () => {
//     jokeContainer.classList.remove("fade");
//     fetch(url)
//     .then(data => data.json())
//     .then(item =>{
//         jokeContainer.textContent = `${item.joke}`;
//         jokeContainer.classList.add("fade");
//     });
